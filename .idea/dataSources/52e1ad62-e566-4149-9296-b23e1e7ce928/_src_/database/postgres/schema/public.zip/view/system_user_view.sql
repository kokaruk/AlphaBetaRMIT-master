CREATE VIEW system_user_view AS SELECT concat("left"(upper((system_users.user_type)::text), 2), lpad((system_users.id)::text, 4, '0'::text)) AS id,
    system_users.name,
    system_users.username,
    system_users.user_type,
    system_users.id AS idint
   FROM system_users;
